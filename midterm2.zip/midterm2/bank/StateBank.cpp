#include "StateBank.h"
#include <iostream>
#include <string>
#include <sstream>
#include <stdlib.h>     /* srand, rand */

using namespace std;
	FederalBank::FederalBank(){
		
	}

    //Override
	void RedGrapes::descTaste() {
		std::cout<<"Red Grappes tastes sweet and sour"<<std::endl;
	}

	//Override
	void RedGrapes::descColor() {
		std::cout<<"Red Grappes are red"<<std::endl;
	}
