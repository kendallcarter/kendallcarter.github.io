#ifndef FRUIT_H_
#define FRUIT_H_

#include <iostream>
#include <string>
#include <sstream>


using namespace std;

class Fruit{
public:
    Fruit();
    
    
    //abstract
    void virtual descTaste()=0;
	void virtual descColor()=0;

    

private:
    

protected:
   

};

#endif