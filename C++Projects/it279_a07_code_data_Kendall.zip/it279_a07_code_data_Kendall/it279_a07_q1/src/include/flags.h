// Define the variable to 1 to test individual section in q1_app
// Only keep one variable to 1 and keep other variables to 0
#define TEST0 0
#define TEST1 1

