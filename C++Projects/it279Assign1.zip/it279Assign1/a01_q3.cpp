#include <iostream>
#include <string>
#include <sstream>
#include <random>
#include <stack>

using std::cout;
using std::endl;
using namespace std;

stack<int> removeSecond(stack<int> *stk) {
int val = stk->pop();
stk -> pop(); 
stk -> push(val);

return *stk;
}

int main(){
    
    
    

    //Generates the 8 random numbers from 0 to 100
    stack<int> myStack;
    default_random_engine defEngine;
    uniform_int_distribution<int> intDistro(0,100);
    for (int i = 1; i <= 8; i++) {
    myStack.push(intDistro(defEngine));
    }

    stack<int> stack;
    stack.push(21);
    stack.push(22);
    stack.push(24);
    stack.push(25);

    
    //prints the contents of the stack
    cout << "The Original List: " << endl;
    for (int i=0; i < myStack.size(); i++) {
    cout <<  myStack[i] << "" "";
    }
    cout << endl;

    while (!stack.empty()) {
        cout << ' ' << stack.top();
        stack.pop();
    }

    //Removes the second node
    stack<int> newStack = removeSecond(myStack);

    //Holds the results, will add together within popping for loop
    string results = "OK";

    int result = 0;
    //Add the resutlts together 
    while(!myStack.empty()){
        result= result + myStack.top();
        myStack.pop();
    }
    std::cout << result << endl; 
      
    return 0;
};