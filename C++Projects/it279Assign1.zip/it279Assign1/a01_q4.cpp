#include <iostream>
#include <string>
#include <sstream>
#include <random>
#include <stack>

using std::cout;
using std::endl;
using namespace std;


int main(){
    cout << "I think this is how you print shit";

    //Navigate to project folder, command shift B to compile, and then run the out file by doiung ./ut in the terminal 
    //while still in the project folder 
    //The one with the Stacks 
    //Fill with random values 1-50

    //Generates the 8 random numbers from 0 to 50
    vector<int> randoms;
    default_random_engine defEngine;
    uniform_int_distribution<int> intDistro(0,50);
    for (int i = 1; i <= 10; i++) {
    randoms.push_back(intDistro(defEngine));
    }
    
    stack<int> stack;
    stack.push(21);
    stack.push(22);
    stack.push(24);
    stack.push(25);

    stack.pop();
 
    while (!stack.empty()) {
        cout << ' ' << stack.top();
        stack.pop();
    }

    //Only prints the sum of the even values, use if statement to test eveness 
    int result = 0;
    
    while(!stack.empty()){
        if (stack.top())
        {
            /* code */
        }
        
        result= result + stack.top();
        stack.pop();
    }
    //Prints sum of even numbers
    std::cout << result << endl; 
    return 0;
};